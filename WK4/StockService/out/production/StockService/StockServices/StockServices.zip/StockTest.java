package StockServices;

public class StockTest {

  @org.junit.jupiter.api.Test
  void getQuote() {
  }

  @org.junit.jupiter.api.Test
  void getQuote1() {
  }

  @org.junit.jupiter.api.Test
  void getStockService() {
  }

  @org.junit.jupiter.api.Test
  void getQuote2() {
  }

  @org.junit.jupiter.api.Test
  void getQuote3() {
  }

  @org.junit.jupiter.api.Test
  void main() {
  }
}
