A simple project that shows the basics of Mockito
